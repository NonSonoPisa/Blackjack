package com.example.wargame;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    ImageView iv_card_left,iv_card_right;
    TextView tv_score_left,tv_score_right;
    Button b_deal;
    int leftScore=0,rightScore=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        iv_card_left= (ImageView) findViewById(R.id.iv_card_left);
        iv_card_right= (ImageView) findViewById(R.id.iv_card_right);
        tv_score_left= (TextView) findViewById(R.id.tv_score_left);
        tv_score_right= (TextView) findViewById(R.id.tv_score_right);
        b_deal= (Button) findViewById(R.id.b_deal);
        Random r= new Random();

        b_deal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //genera il valore delle due carte
                int leftCard= r.nextInt(13)+2;
                int rightCard= r.nextInt(13)+2;

                //mostra le carte
                int leftImage=getResources().getIdentifier("card"+leftCard,"drawable",getPackageName());
                iv_card_left.setImageResource(leftImage);
                int rightImage=getResources().getIdentifier("card"+rightCard,"drawable",getPackageName());
                iv_card_right.setImageResource(rightImage);
                //compara le carte e aggiunge punti al vincitore
                if(leftCard>rightCard){
                    leftScore++;
                    tv_score_left.setText(String.valueOf(leftScore));
                }
                else if(leftCard<rightCard){
                    rightScore++;
                    tv_score_right.setText(String.valueOf(rightScore));
                }
                else{
                    Toast.makeText(MainActivity.this, "WAR",Toast.LENGTH_SHORT).show();
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                if( rightScore==26){
                    Toast.makeText(MainActivity.this, "Right player has won the war",Toast.LENGTH_SHORT).show();
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    rightScore=0;
                    tv_score_right.setText(String.valueOf(rightScore));
                    leftScore=0;
                    tv_score_left.setText(String.valueOf(leftScore));
                    leftImage=getResources().getIdentifier("dorso","drawable",getPackageName());
                    iv_card_left.setImageResource(leftImage);
                    rightImage=getResources().getIdentifier("dorso","drawable",getPackageName());
                    iv_card_right.setImageResource(rightImage);

                }
                if( leftScore==26){
                    Toast.makeText(MainActivity.this, "Left player has won the war",Toast.LENGTH_SHORT).show();
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    rightScore=0;
                    tv_score_right.setText(String.valueOf(rightScore));
                    leftScore=0;
                    tv_score_left.setText(String.valueOf(leftScore));
                    leftImage=getResources().getIdentifier("dorso","drawable",getPackageName());
                    iv_card_left.setImageResource(leftImage);
                    rightImage=getResources().getIdentifier("dorso","drawable",getPackageName());
                    iv_card_right.setImageResource(rightImage);

                }

            }
        });

    }
}