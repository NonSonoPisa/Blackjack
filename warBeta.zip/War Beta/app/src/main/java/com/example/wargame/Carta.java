package com.example.wargame;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
public class Carta {
    int seme;
    int val;
    String image;
    public Carta(int s,int valore){
        seme=s;
        val=valore;
        image="card"+val+seme;
    }

    public int getSeme() {
        return seme;
    }

    public int getVal() {
        return val;
    }

    public String getImage() {
        return image;
    }
}
