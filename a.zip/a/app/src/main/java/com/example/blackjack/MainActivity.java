package com.example.blackjack;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        String Nome;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    protected void gioca(View view){

        Nome=findViewById(R.layout.activity_main.nomePlayer).text;

    }
}